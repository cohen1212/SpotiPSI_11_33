import { useEffect, useRef, useState } from "react";
import type { Song } from "../types/types";

type UsePlayLogicReturn = {
    currentSong: Song | null;
    isPlaying: boolean;
    currentTime: number;
    duration: number;
    play: (song: Song) => void;
    playNext: () => void;
    playPrevious: () => void;
    togglePlayPause: () => void;
    seek: (time: number) => void;
};

const usePlayLogic = (songs: Song[]): UsePlayLogicReturn => {
    const [currentSong, setCurrentSong] = useState<Song | null>(null);
    const [isPlaying, setIsPlaying] = useState<boolean>(false);
    const [currentTime, setCurrentTime] = useState<number>(0);
    const [duration, setDuration] = useState<number>(0);

    const audioRef = useRef<HTMLAudioElement | null>(null);

    const getSongIndex = (songId: string) => {
        return songs.findIndex((song) => song.id === songId);
    };

    const createAudio = (song: Song) => {
        if (audioRef.current) {
            audioRef.current.pause();
            audioRef.current.src = "";
        }

        const audio = new Audio(`/songs/${song.id}.mp3`);
        audioRef.current = audio;
        return audio;
    };

    const play = (song: Song) => {
        if (currentSong?.id === song.id) {
            setIsPlaying(true);
            return;
        }

        setCurrentSong(song);
        setCurrentTime(0);
        setDuration(0);
        setIsPlaying(true);
    };

    const togglePlayPause = () => {
        if (!currentSong) {
            if (songs.length > 0) {
                play(songs[0]);
            }
            return;
        }

        setIsPlaying((prev) => !prev);
    };

    const playNext = () => {
        if (!currentSong || songs.length === 0) {
            return;
        }

        const currentIndex = getSongIndex(currentSong.id);
        const nextIndex = (currentIndex + 1) % songs.length;
        setCurrentSong(songs[nextIndex]);
        setCurrentTime(0);
        setDuration(0);
        setIsPlaying(true);
    };

    const playPrevious = () => {
        if (!currentSong || songs.length === 0) {
            return;
        }

        const currentIndex = getSongIndex(currentSong.id);
        const previousIndex = (currentIndex - 1 + songs.length) % songs.length;
        setCurrentSong(songs[previousIndex]);
        setCurrentTime(0);
        setDuration(0);
        setIsPlaying(true);
    };

    const seek = (time: number) => {
        if (!audioRef.current) {
            return;
        }

        audioRef.current.currentTime = time;
        setCurrentTime(time);
    };

    useEffect(() => {
        if (!currentSong) {
            return;
        }

        const audio = createAudio(currentSong);

        const handleLoadedMetadata = () => {
            setDuration(audio.duration || 0);
        };

        const handleTimeUpdate = () => {
            setCurrentTime(audio.currentTime);
        };

        const handleEnded = () => {
            const currentIndex = songs.findIndex((song) => song.id === currentSong.id);
            const nextIndex = (currentIndex + 1) % songs.length;
            setCurrentSong(songs[nextIndex]);
            setCurrentTime(0);
            setDuration(0);
            setIsPlaying(true);
        };

        audio.addEventListener("loadedmetadata", handleLoadedMetadata);
        audio.addEventListener("timeupdate", handleTimeUpdate);
        audio.addEventListener("ended", handleEnded);

        if (isPlaying) {
            void audio.play().catch((error) => {
                console.error("Failed to play audio:", error);
            });
        }

        return () => {
            audio.pause();
            audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
            audio.removeEventListener("timeupdate", handleTimeUpdate);
            audio.removeEventListener("ended", handleEnded);
        };
    }, [currentSong, songs]);

    useEffect(() => {
        if (!audioRef.current) {
            return;
        }

        if (isPlaying) {
            void audioRef.current.play().catch((error) => {
                console.error("Failed to play audio:", error);
            });
        } else {
            audioRef.current.pause();
        }
    }, [isPlaying]);

    return {
        currentSong,
        isPlaying,
        currentTime,
        duration,
        play,
        playNext,
        playPrevious,
        togglePlayPause,
        seek,
    };
};

export default usePlayLogic;